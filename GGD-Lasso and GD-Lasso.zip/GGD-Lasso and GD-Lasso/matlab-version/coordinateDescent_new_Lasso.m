function [ W ] = coordinateDescent_new_Lasso( X,Z,eta )
[K D]=size(X);
[N D]=size(Z);
W=zeros(N,K);
dim = N*K;
lambda=ones(K*N,1)*eta;
funObj = @(w)Model_new_Lasso(w,X',Z',alpha, beta, Ds,Dg) % Loss function that L1 regularization is applied to
w_init = rand(dim,1); % Initial value for iterative optimizer
wLASSO_2 = L1General2_OWL(funObj,w_init,lambda);
W=DblVec2Matrix(wLASSO_2, 1, K*N,N,K);
end
