function [ W, S, G, L ] = GCLasso_new(X,Z,eta,lambda,alpha,beta,gamma,rho,S0,G0)
[K D]=size(X);
[N D]=size(Z);
W= LassoMatrix(X,Z,eta);%
%S=S0;
%G=G0;
S=rand(size(S0));
G=rand(size(G0));



TOL = 1e-5;
MAXITeration = 50;
iteration=0;
oldW=ones(size(W));
oldS=ones(size(S));
oldG=ones(size(G));

c1=[];


while ( sum(sum(abs(S-oldS))) > TOL || sum(sum(abs(G-oldG))) > TOL || sum(sum(abs(W-oldW))) > TOL ) && iteration < MAXITeration
            
        oldS=S;
        oldG=G;
        oldW=W;
        
        ZZ=Z';
        XX=X';
        WW=W';
        
        [U,W2,V] = svd(ZZ-XX*WW,'econ');
        VT = V';
        w = diag(W2);
        ind = find(w>lambda);
        W2 = diag(w(ind)-lambda);
        L = U(:,ind)*W2*VT(ind,:);
        L=L';
        
        
        Sold = ones(size(S));
        Gold = ones(size(G));


        TOL = 1e-5;
        MAXIT = 100;
        iter=0;
        
        W_t_W=W'*W;
            W_W_t=W*W';
            W_t_W_pos=W_t_W;
            W_t_W_neg=W_t_W;
            W_t_W_pos(W_t_W_pos<0)=0;
            W_t_W_neg(W_t_W_neg>0)=0;
            W_t_W_neg=-1*W_t_W_neg;
            W_W_t_pos=W_W_t;
            W_W_t_neg=W_W_t;
            W_W_t_pos(W_W_t_pos<0)=0;
            W_W_t_neg(W_W_t_neg>0)=0;
            W_W_t_neg=-1*W_W_t_neg;
            J_K=ones(K,K);
            J_N=ones(N,N);
            diagWtW=diag(diag(W_t_W));
            diagWWt=diag(diag(W_W_t));
            JdWtW = diagWtW*J_K;
            JdWWt = diagWWt*J_N;
            
        while (sum(sum(abs(S-Sold))) > TOL || sum(sum(abs(G-Gold))) > TOL) && iter < MAXIT
            Sold=S;
            Gold=G;
            
            
            temp1=alpha*W_t_W_pos+2*gamma*S0;
            temp2=2*gamma*S+alpha*W_t_W_neg+alpha*JdWtW;
            temp3=beta*W_W_t_pos+2*rho*G0;
            temp4=2*rho*G+beta*W_W_t_neg+beta*JdWWt;

            temp5 = gdivide((temp1),(temp2));
           temp5(isinf(temp5))=0;
           temp5(isnan(temp5))=0;
            
            temp6 = gdivide((temp3),(temp4));
           temp6(isinf(temp6))=0;
           temp6(isnan(temp6))=0;
            
            S=S.*(gsqrt(temp5));
            G=G.*(gsqrt(temp6));
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              obj=opjectiveV(X,Z,W,L,S,G,eta,lambda,alpha,beta,gamma,rho,S0,G0);
%              
% %              if(obj>c1(1,end))
% %                  break;
% %              end
%              
%              c1=[c1 obj];
            
             

            iter=iter+1;

        end
        DS=diag(sum(S,2));
        Ds=DS-S;
        DG=diag(sum(G,2));
        Dg=DG-G;
        W=coordinateDescent_new( X,(Z-L),alpha,beta,Ds,Dg,eta );

        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         obj=opjectiveV(X,Z,W,L,S,G,eta,lambda,alpha,beta,gamma,rho,S0,G0);
%          
% %          if(obj>c1(1,end))
% %                  break;
% %              end
%          
%          c1=[c1 obj];
         
         
         
        iteration=iteration+1;
    %    disp(iteration);
end

%  figure;
%  plot([1:1:size(c1,2)],c1,'-*r');

end

