function [ W, S, G, L ] = GGDLasso_new(X,Z,eta,lambda,alpha,beta,kappa1,kappa2,S0,G0,pathway, SNPlocation)
[K D]=size(X);
[N D]=size(Z);
%W= load(warmstart);%zeros(N,K);%
W=LassoMatrix(X,Z,eta);%
S=S0;
G=G0;


TOL = 1e-4;
MAXITeration = 50;
iteration=0;
oldW=ones(size(W));

c1=[];
cd MinMaxSelection;

while ( sum(sum(abs(W-oldW))) > TOL ) && iteration < MAXITeration
            

        oldW=W;
        
       
        ZZ=Z';
        XX=X';
        WW=W';
        
        
        [U,W2,V] = svd(ZZ-XX*WW,'econ');
        VT = V';
        w = diag(W2);
        ind = find(w>lambda);
        W2 = diag(w(ind)-lambda);
        L = U(:,ind)*W2*VT(ind,:);
        L=L';
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        SNP_simi=abs(W'*W);
        Gene_simi=abs(W*W');
        
        
        [snp_x_max snp_y_max]=maxk2(triu(SNP_simi,1),kappa1);
        temp1=9999999999999999*ones(size(SNP_simi));
        temp1=tril(temp1,0);
        [snp_x_min,snp_y_min]=mink2((temp1+SNP_simi),kappa1);
        
        locationNB = abs(SNPlocation(snp_x_max,2)-SNPlocation(snp_y_max,2));
        locationNB = (locationNB<1000);
		locationNB = locationNB & (SNPlocation(snp_x_max,1)==SNPlocation(snp_y_max,1));
        S_ind=zeros(size(snp_x_max,1),1);
        for i=1:size(snp_x_max,1)
            if S(snp_x_max(i,1),snp_y_max(i,1))==0
                S_ind(i,1)=1;
            end
        end
		locationNB=locationNB&S_ind;
        num_candidate_2add = sum(sum(locationNB));
        
        
        
        locationNB2 = abs(SNPlocation(snp_x_min,2)-SNPlocation(snp_y_min,2));
        locationNB2 = (locationNB2>1000);       
		locationNB2 = locationNB2 | (SNPlocation(snp_x_min,1)~=SNPlocation(snp_x_min,1));
        S_indn=zeros(size(snp_x_min,1),1);
        for i=1:size(snp_x_min,1)
            if S(snp_x_min(i,1),snp_y_min(i,1))==1
                S_indn(i,1)=1;
            end
        end
		locationNB2=locationNB2&S_indn;
        num_candidate_2remove = sum(sum(locationNB2));
        
        num_candidate_snp=min(min([num_candidate_2add num_candidate_2remove]));
        
        disp('updated S:');
        disp(num_candidate_snp);
        
        
        [gene_x_max,gene_y_max]=maxk2(triu(Gene_simi,1),kappa2);
        temp1=9999999999999999*ones(size(Gene_simi));
        temp1=tril(temp1,0);
        [gene_x_min,gene_y_min]=mink2((temp1+Gene_simi),kappa2);
        

            
        G_ind=zeros(size(gene_x_max,1),1);
        for i=1:size(gene_x_max,1)
            if (pathway(gene_x_max(i,1),gene_y_max(i,1))==1 || pathway(gene_y_max(i,1),gene_x_max(i,1))==1) && G(gene_x_max(i,1),gene_y_max(i,1))==0 && G(gene_y_max(i,1),gene_x_max(i,1))==0
                G_ind(i,1)=1;
            end
        end
        num_candidate_2add = sum(sum(G_ind));
        
        G_indn=zeros(size(gene_x_min,1),1);
        for i=1:size(gene_x_min,1)
            if (pathway(gene_x_min(i,1),gene_y_min(i,1))==0 && pathway(gene_y_min(i,1),gene_x_min(i,1))==0) && (G(gene_x_min(i,1),gene_y_min(i,1))==1 || G(gene_y_min(i,1),gene_x_min(i,1))==1)
                G_indn(i,1)=1;
            end
        end
        num_candidate_2remove = sum(sum(G_indn));
        
        num_candidate_gene=min(min([num_candidate_2add num_candidate_2remove]));
        
        disp('updated G:');
        disp(num_candidate_gene);
        
        
        if( num_candidate_snp ==0 && num_candidate_gene==0)
            break;
        end    
        
        
        candidate_snp_x_2add= snp_x_max((reviseIndex(locationNB,num_candidate_snp)==1));
        candidate_snp_y_2add= snp_y_max((reviseIndex(locationNB,num_candidate_snp)==1));
        
        candidate_snp_x_2remove= snp_x_min(reviseIndex(locationNB2,num_candidate_snp)==1);
        candidate_snp_y_2remove= snp_y_min((reviseIndex(locationNB2,num_candidate_snp)==1));
        
        for i=1:num_candidate_snp
            S(candidate_snp_x_2add(i,1),candidate_snp_y_2add(i,1))=1;
            S(candidate_snp_y_2add(i,1),candidate_snp_x_2add(i,1))=1;
            S(candidate_snp_x_2remove(i,1),candidate_snp_y_2remove(i,1))=0;
            S(candidate_snp_y_2remove(i,1),candidate_snp_x_2remove(i,1))=0;
        end
        
        candidate_gene_x_2add= gene_x_max((reviseIndex(G_ind,num_candidate_gene)==1));
        candidate_gene_y_2add= gene_y_max((reviseIndex(G_ind,num_candidate_gene)==1));
        
        candidate_gene_x_2remove= gene_x_min((reviseIndex(G_indn,num_candidate_gene)==1));
        candidate_gene_y_2remove= gene_y_min((reviseIndex(G_indn,num_candidate_gene)==1));
        
        for i=1:num_candidate_gene
            G(candidate_gene_x_2add(i,1),candidate_gene_y_2add(i,1))=1;
            G(candidate_gene_y_2add(i,1),candidate_gene_x_2add(i,1))=1;
            G(candidate_gene_x_2remove(i,1),candidate_gene_y_2remove(i,1))=0;
            G(candidate_gene_y_2remove(i,1),candidate_gene_x_2remove(i,1))=0;
        end      
        
        
            
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        DS=diag(sum(S,2));
        Ds=DS-S;
        DG=diag(sum(G,2));
        Dg=DG-G;
        W=coordinateDescent_new( X,(Z-L),alpha,beta,Ds,Dg,eta );

        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         obj=opjectiveV(X,Z,W,L,S,G,eta,lambda,alpha,beta,gamma,rho,S0,G0);
%          
% %          if(obj>c1(1,end))
% %                  break;
% %              end
%          
%          c1=[c1 obj];
         
         
         
        iteration=iteration+1;
        disp('iteration of G S');
        disp(iteration);
    %    disp(iteration);
end

%  figure;
%  plot([1:1:size(c1,2)],c1,'-*r');

end

