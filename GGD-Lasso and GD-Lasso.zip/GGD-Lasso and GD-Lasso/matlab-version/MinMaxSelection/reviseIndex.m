function [ rec ] = reviseIndex( vec, num )

    rec=zeros(size(vec,1),1);
    if num==0
        return;
    end
    count=0;
    for i=1:size(vec,1)
        if vec(i,1) == 1
            count=count+1;
            rec(i,1)=1;
            if count == num
                break;
            end
        end
    end



end

