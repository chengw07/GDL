function [x y v] = mink2(W,k)
    [N K]=size(W);
    W2=reshape(W,1,N*K);
    [vv,xx]=mink(W2,k);
    y=ceil(xx/K);
    x= mod(xx,K);
    x=x';
    y=y';
    x(x==0)=N;
    v=vv';
end