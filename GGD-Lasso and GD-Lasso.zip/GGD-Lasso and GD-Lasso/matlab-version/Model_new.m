function [f,g] = Model_new(input,XX,y,alpha, beta, Ds,Dg)
% w(feature,1)
% X(instance,feature)
% y(instance,1)

    [D K]=size(XX);
    [D N]=size(y);
    % Use 2 matrix-vector products with X
    
    W=DblVec2Matrix(input, 1, N*K,N,K);
    
    
    X=(standardizeCols(XX))';
    Z=y';    
   

	f = 0;
    temp1=(Z-W*X);
    temp=temp1'*temp1;
    f= 0.5*trace(temp)+alpha*trace(W*Ds*W')+beta*trace(W'*Dg*W);
	
    disp(f);

	g1=-1*Z*X'+W*X*X'+2*alpha*W*Ds'+2*beta*Dg*W;
    g=reshape(g1,size(g1,1)*size(g1,2),1);
end