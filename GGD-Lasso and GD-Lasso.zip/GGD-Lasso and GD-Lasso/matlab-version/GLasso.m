function [ W, L  ] = GLasso_new(X,Z,eta,lambda,alpha,beta,S0,G0)

[K D]=size(X);
[N D]=size(Z);
W=LassoMatrix(X,Z,eta);%zeros(N,K);


TOL = 1e-5;
MAXITeration = 50;
iteration=0;
oldW=ones(size(W));

while ( sum(sum(abs(W-oldW))) > TOL ) && iteration < MAXITeration
        
        oldW=W;
        
        ZZ=Z';
        XX=X';
        WW=W';
        
        [U,W2,V] = svd(ZZ-XX*WW,'econ');
        VT = V';
        w = diag(W2);
        ind = find(w>lambda);
        W2 = diag(w(ind)-lambda);
        L = U(:,ind)*W2*VT(ind,:);
        L=L';


        DS=diag(sum(S0,2));
        Ds=DS-S0;
        DG=diag(sum(G0,2));
        Dg=DG-G0;
        W=coordinateDescent_new( X,Z-L,alpha,beta,Ds,Dg,eta );

        iteration=iteration+1;
       % disp(iteration);
end


end

