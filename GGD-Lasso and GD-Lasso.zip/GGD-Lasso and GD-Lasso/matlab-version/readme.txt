The matlab version of proposed G-Lasso, GD-Lasso, and GGD-Lasso.
Please refer simulation.m for the use of those methods.
GGD-Lasso needs extra snp location information "yeast_SNP_location.txt" and PPI information.