function [ R ] = DblVec2Matrix(vec, k1, k2,Ar,Ac)
    R=zeros(Ar,Ac);
    [r c] =size(vec);
	if ((k2>r*c)||(k2-k1+1)~=(Ar*Ac)) 
		%exit(1);
        return;
    end

	k=k1;

	for j = 1:1:Ac
		for i=1:1:Ar
			R(i,j) = vec(k,1);
			k=k+1;
        end
    end
end