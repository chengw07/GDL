function [ W ] = coordinateDescent_new( X,Z,alpha,beta,Ds,Dg,eta )
[K D]=size(X);
[N D]=size(Z);
dim = N*K;
lambda=ones(K*N,1)*eta;
funObj = @(w)Model_new(w,X',Z',alpha, beta, Ds,Dg) % Loss function that L1 regularization is applied to
w_init = rand(dim,1); % Initial value for iterative optimizer
wLASSO_2 = L1General2_SPG(funObj,w_init,lambda);
W=DblVec2Matrix(wLASSO_2, 1, K*N,N,K);
end
