clear all;
addpath(genpath(pwd));
mexAll
%%%%%%%%%% true W
W=zeros(10,100);
W(1:3,21)=1;
W(1:3,28)=1;
W(1:3,45)=1;
W(1:3,98)=1;
W(4:6,10)=1;
W(4:6,30)=1;
W(4:6,90)=1;
W(4:6,95)=1;
W(7:10,5)=1;
W(7:10,19)=1;
W(7:10,65)=1;
W(7:10,85)=1;
W(1:10,57)=1;
W(1:6,70)=1;



%%%%%%%%%%% concounding factors
hidden_num = 10;
D=112;
H=randn(D,hidden_num);
tau=0.1;
Sigma= tau*H*H';
mu=zeros(1,D);
MU=[];
for i=1:10
    r = mvnrnd(mu,Sigma,1);
    MU=[MU;r];
end

%%%%%%%%%%%  errors
gamma_e = 1;
E=sqrt(gamma_e) * randn(10,D);

%%%%%%%%%%%   X
X=load('mD.txt');
X=X(1:100,:);

%%%%%%%%%%%  Z
Z=W*X+MU+E;

eta= 10;
lambda=10;
alpha=10;
beta=10;
gamma=10;
rho=10;


%S0=rbf(W',2);%%CalculateAffinity(W','cosine');%
%G0=rbf(W,2);%%CalculateAffinity(W,'cosine');%
G0=zeros(size(W,1),size(W,1));
S0=zeros(size(W,2),size(W,2));
S0(21,28)=1;S0(21,45)=1;S0(21,98)=1;S0(28,45)=1;S0(28,98)=1;S0(45,98)=1;
S0(21,57)=1;S0(28,57)=1;S0(45,57)=1;S0(98,57)=1;%S0(21,70)=1;S0(28,70)=1;S0(45,70)=1;S0(98,70)=1;%%%%%%%%
S0(10,57)=1;S0(30,57)=1;S0(90,57)=1;S0(95,57)=1;%S0(10,70)=1;S0(30,70)=1;S0(90,70)=1;S0(95,70)=1;%%%%%%%%%
S0(10,30)=1;S0(10,90)=1;S0(10,95)=1;S0(30,90)=1;S0(30,95)=1;S0(90,95)=1;
%S0(5,19)=1;S0(5,65)=1;S0(5,85)=1;S0(19,65)=1;S0(19,85)=1;S0(65,85)=1;%%%%%%%%%%
%S0(5,57)=1;S0(19,57)=1;S0(65,57)=1;S0(85,57)=1;%%%%%%%%%%%%%
S0=S0+S0';
G0(1,2)=1;G0(1,3)=1;G0(2,3)=1;G0(4,5)=1;G0(4,6)=1;G0(5,6)=1;%G0(7,8)=1;G0(7,9)=1;G0(7,10)=1;G0(8,9)=1;G0(8,9)=1;G0(9,10)=1;%%%%%%%%%%%%%%%%
G0=G0+G0';

G0=G0+eye(size(W,1));
S0=S0+eye(size(W,2));





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%normalize Z
[Z_t, mu, sigma] = standardizeCols(Z');
Z=Z_t';
[X_t, mu, sigma] = standardizeCols(X');
X=X_t';




etaChoosen=4;
lambdaChoosen=5;
betaChoosen=7;
alphaChoosen=0.1;

[W3, L3]=GLasso(X,Z,etaChoosen,lambdaChoosen,alphaChoosen,betaChoosen,S0,G0);



etaChoosen=4;
lambdaChoosen=5;
alphaChoosen=1;
betaChoosen=200;
gammaChoosen=1;
rhoChoosen=8000;


[W4, S4, G4, L4]=GDLasso(X,Z,etaChoosen,lambdaChoosen,alphaChoosen,betaChoosen,gammaChoosen,rhoChoosen,S0,G0);

%pathway=load('pathway.txt');
%pathway=rand(size(G0),size(G0));

%SNPlocation=load('yeast_SNP_location.txt');

%[W5, S, G, L]=GGDLasso(X,Z,etaChoosen,lambdaChoosen,alphaChoosen,betaChoosen,kappa1,kappa2,S0,G0,pathway, SNPlocation);

W(W>0)=1;
W3=abs(W3);
W4=abs(W4);
W3=W3/max(max(W3));
W4=W4/max(max(W4));

subplot(1,3,1);
imagesc(W');
title('\fontsize{20}W-true','FontName','Times New Roman');
C1=colormap(gray);
colormap(1-C1);
colorbar;

subplot(1,3,2);
imagesc(W3');
title('\fontsize{20}G-lasso','FontName','Times New Roman');
C1=colormap(gray);
colormap(1-C1);
colorbar;

subplot(1,3,3);
imagesc(W4');
title('\fontsize{20}GD-Lasso','FontName','Times New Roman');
C1=colormap(gray);
colormap(1-C1);
colorbar;
