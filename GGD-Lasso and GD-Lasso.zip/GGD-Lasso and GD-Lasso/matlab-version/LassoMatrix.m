function [ result ] = LassoMatrix(X,Z,lambda)
[K D]=size(X);
[N D]=size(Z);
result = [];
for i=1:N
    result = [result LassoBlockCoordinate(X',Z(i,:)',lambda)];
end
result = result';
end

