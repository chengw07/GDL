function [ W ] = coordinateDescent( X,Z,alpha,beta,Ds,Dg,eta )
[K D]=size(X);
[N D]=size(Z);
W=zeros(N,K);

X_X_t = X*X';
Z_X_t = Z*X';

Wold = ones(N,K);
TOL = 1e-5;
MAXIT = 100;
iter=0;
c=[];
while sum(sum(abs(W-Wold))) > TOL && iter < MAXIT
    Wold=W;
    for i=1:N
        for j=1:K
            temp1=0;
            temp2=0;
            temp3=0;
            for k=1:K
                if k ~= j
                    temp1=temp1+W(i,k)*X_X_t(k,j);
                    temp2=temp2+W(i,k)*Ds(k,j);
                end
            end  
            for k=1:N
                if k ~= i
                    temp3=temp3+Dg(i,k)*W(k,j);
                end
            end
            m=Z_X_t(i,j)-temp1-2*alpha*temp2-2*beta*temp3;
            sign=0;
            if(m>0)
                sign=1;
            end
            if(m<0)
                sign=-1;
            end
            SS=0;
            if(abs(m)-eta>0)
              SS=sign*(abs(m)-eta);
            else
                SS=0;
            end

            W(i,j)=SS/(X_X_t(j,j)+2*alpha*Ds(j,j)+2*beta*Dg(i,i));
            
           % c=[c objCal(X,Z,W,Ds,Dg,alpha,beta,eta)];
            
        end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    W(isinf(W))=0;
    W(isnan(W))=0;
    iter=iter+1;
    
    
end
% figure;
% plot([1:1:size(c,2)],c,'-*r');


end


function [obj]=objCal(X,Z,W,Ds,Dg,alpha,beta,eta)
    obj=1/2*trace((Z-W*X)'*(Z-W*X))+eta*sum(sum(abs(W)))+alpha*trace(W*Ds*W')+beta*trace(W'*Dg*W);
end

