//$$ example.cpp                             Example of use of matrix package

//#define WANT_STREAM                  // include.h will get stream fns
#define WANT_MATH                    // include.h will get math fns
                                     // newmatap.h will get include.h
#include <iostream>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <fstream>
#include <ctime> 
#include <cstdlib>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <ctime>

//#include "C:\\Users\\weicheng\\Dropbox\\NIPS2013\\ALGLIB\\src\\statistics.h"

#include "OWLQN.h"
#include "leastSquares.h"
#include "logreg.h"

#include "TwoLayerLinearRegression.h"
#include "Lasso.h"

#include "newmatap.h"                // need matrix applications
//#include "newmatio.h"                // need matrix output routines

//#ifdef use_namespace
//using namespace NEWMAT;              // access NEWMAT namespace
//#endif
typedef struct
{
int row;
int column;
double weight;
} Triple;
using namespace std;

// demonstration of matrix package on linear regression problem
struct compareTripleSmall
{
	bool operator()(Triple a,Triple b) //??????????,?bool??,???qsort()?????int??,?????????
	{
		return a.weight>b.weight; //?????,?????????"a>b" 
	}
};

struct compareTripleLarge
{
	bool operator()(Triple a,Triple b) //??????????,?bool??,???qsort()?????int??,?????????
	{
		return a.weight<b.weight; //?????,?????????"a>b" 
	}
};
//using namespace std;
void printUsageAndExit() {
	cout << "Orthant-Wise Limited-memory Quasi-Newton trainer" << endl;
	cout << "trains L1-regularized logistic regression or least-squares models" << endl << endl;
	cout << "usage: feature_file label_file regWeight output_file [options]" << endl;
	cout << "  feature_file   input feature matrix in Matrix Market format (mxn real coordinate or array)" << endl;
	cout << "                   rows represent features for each instance" << endl;
	cout << "  label_file     input instance labels in Matrix Market format (mx1 real array)" << endl;
	cout << "                   rows contain single real value" << endl;
	cout << "                   for logistic regression problems, value must be 1 or -1" << endl;
	cout << "  regWeight      coefficient of l1 regularizer" << endl;
	cout << "  output_file    output weight vector in Matrix Market format (1xm real array)" << endl << endl;
	cout << "options:" << endl;
	cout << "  -ls            use least squares formulation (logistic regression is default)" << endl;
	cout << "  -q             quiet.  Suppress all output" << endl;
	cout << "  -tol <value>   sets convergence tolerance (default is 1e-4)" << endl;
	cout << "  -m <value>     sets L-BFGS memory parameter (default is 10)" << endl;
	cout << "  -l2weight <value>" << endl;
	cout << "                 sets L2 regularization weight (default is 0)" << endl;
	cout << endl;
	exit(0);
}
int** loadSNPlocation_mouse(const char* file)
{

	int start;
	int end;
	int chr;
	string snp_name;

	
		ifstream xfile(file);

		if (!xfile.good()) 
		{
			cerr << "error opening SNP location matrix file " << file << endl;
			exit(1);
		}


		string s;
		getline(xfile, s);
		int rowIndex = 0;
		stringstream st(s);

		int num_snps = 0;
		st >> num_snps;
		int** index=new int*[num_snps];
		for(int i = 0; i < num_snps; i++)
		{
		   index[i]=new int[2];
		   for(int j = 0; j < 2; j++)
		   {
			  index[i][j] = 0;
		   }
		}


		while( !xfile.eof() ) {
		  getline(xfile, s);
		  if(s.size()<5)
			  break;

		  stringstream st(s);
		  st >> snp_name;
		  st >> chr;
		  st >> start;
		  index[rowIndex][0]=start;
		  index[rowIndex][1]=chr;
		  rowIndex++;
		}

		xfile.close();

	return index;

}
int** loadGenelocation_mouse(const char* file)
{

	
		ifstream xfile(file);

		if (!xfile.good()) 
		{
			cerr << "error opening Gene location matrix file " << file << endl;
			exit(1);
		}


		string s;
		getline(xfile, s);
		int rowIndex = 0;
		int num_genes=0;
		stringstream st(s);
		st>>num_genes;

		int** index=new int*[num_genes];
		for(int i = 0; i < num_genes; i++)
		{
		   index[i]=new int[2];
		   for(int j = 0; j < 2; j++)
		   {
			  index[i][j] = 0;
		   }
		}
		string gene_name;
		int chr;
		int start;
		int end;
		while( !xfile.eof() ) {
		  getline(xfile, s);
		  if(s.size()<5)
			  break;
		  stringstream st(s);
		  st >> gene_name;

		  std::string tmp_line;
		  st >> tmp_line;
		  std::stringstream ss;
		  ss << tmp_line;
		  ss >> chr;

		  st >> start;
		  st >> end;
		  index[rowIndex][0]=start;
		  if(ss.fail())chr = 20;
		  index[rowIndex][1]=chr;
		  rowIndex++;
		}

		xfile.close();
	
	return index;

}
Matrix loaddata3New(const char* file)
{
	
	
	int row;
	int column;
	
		ifstream xfile(file);

		if (!xfile.good()) 
		{
			cerr << "error opening G0 matrix file " << file << endl;
			exit(1);
		}


		string s;
		int num_expression;
		xfile >> num_expression;
		Matrix data(num_expression,num_expression);
		data=0;
		

		IdentityMatrix data2(num_expression); 
			
		while( !xfile.eof() ) {
		  xfile >> row >> column;
		  data(row+1,column+1) = 1;
		  data(column+1, row+1 ) = 1;
		}
	    data= data+data2;
		xfile.close();
	
	return data;

}
Matrix loaddata1New(const char* file)
{
	
	
	int row;
	int column;
	
		ifstream xfile(file);

		if (!xfile.good()) 
		{
			cerr << "error opening S0 matrix file " << file << endl;
			exit(1);
		}


		string s;
		int num_snps = 0;
		xfile >>num_snps;
		Matrix data(num_snps,num_snps);
		data=0;

		IdentityMatrix data2(num_snps); 
		int count=0;
		while( !xfile.eof() ) {
		  xfile >> row >> column;
		  data(row+1,column+1) = 1;
		  data(column+1, row+1 ) = 1;
		  count++;
		  if(count>500000)
			  break;
		}
	    data= data+data2;
		xfile.close();
	
	return data;

}
Matrix loaddataPathWay(const char* file)
{

	
	int row;
	int column;
	
		ifstream xfile(file);

		if (!xfile.good()) 
		{
			cerr << "error opening Pathway matrix file " << file << endl;
			exit(1);
		}


		string s;
	

	//	IdentityMatrix data2(4474); 
		int num_genes = 0;
		xfile>>num_genes;

		Matrix data(num_genes,num_genes);

		data=0;
			
		while( !xfile.eof() ) {
		  xfile >> row >> column;
		  data(row+1,column+1) = 1;
		  data(column+1, row+1 ) = 1;
		}
//	    data= data+data2;
		xfile.close();
	
	return data;

}
Matrix loaddataNew(const char* file)
{
	
	
	int value;

	{
		ifstream xfile(file);

		if (!xfile.good()) 
		{
			cerr << "error opening W matrix file " << file << endl;
			exit(1);
		}


		string s;
		
		
		double value;
		int rowIndex = 1;
		getline(xfile, s);
		int rowN=0;
		int colN=0;
		stringstream st(s);
		st >> rowN >> colN;
		Matrix data(rowN,colN);
		data=0;
		while( !xfile.eof() ) {
		  getline(xfile, s);
		  if(s.length() < 10)
			  break;
		  stringstream st(s);
		  for( int i=1; i<= colN; i++)
		  {
			  st >> value;
			  data(rowIndex,i) = value;
		  }
		  rowIndex++;
		  
		}

		xfile.close();
		return data;
	}
	

}

Matrix loaddata6(const char* file,int row, int col)
{
	Matrix data(row,col);
	data=0;
	
	int value;

	{
		ifstream xfile(file);

		if (!xfile.good()) 
		{
			cerr << "error opening W matrix file " << file << endl;
			exit(1);
		}


		string s;
		
		data = 0;
		double value;
		int rowIndex = 1;
		while( !xfile.eof() ) {
		  getline(xfile, s);
		  if(s.length() < 10)
			  break;
		  stringstream st(s);
		  for( int i=1; i<= col; i++)
		  {
			  st >> value;
			  data(rowIndex,i) = value;
		  }
		  rowIndex++;
		  
		}

		xfile.close();
	}
	return data;

}
int** loadSNPlocation(const char* file)
{
	int** index=new int*[1017];
	for(int i = 0; i < 1017; i++)
	{
	   index[i]=new int[2];
       for(int j = 0; j < 2; j++)
	   {
          index[i][j] = 0;
	   }
	}

	int start;
	int end;
	int chr;

	{
		ifstream xfile(file);

		if (!xfile.good()) 
		{
			cerr << "error opening SNP location matrix file " << file << endl;
			exit(1);
		}


		string s;
		getline(xfile, s);
		int rowIndex = 0;
		while( !xfile.eof() ) {
		  getline(xfile, s);
		  if(s.size()<5)
			  break;

		  stringstream st(s);
		  st >> chr;
		  st >> start;
		  st >> end;
		  index[rowIndex][0]=start;
		  index[rowIndex][1]=chr;
		  rowIndex++;
		}

		xfile.close();
	}
	return index;

}
int** loadGenelocation(const char* file)
{
	int** index=new int*[4474];
	for(int i = 0; i < 4474; i++)
	{
	   index[i]=new int[2];
       for(int j = 0; j < 2; j++)
	   {
          index[i][j] = 0;
	   }
	}

	int start;
	int end;
	int chr;
	{
		ifstream xfile(file);

		if (!xfile.good()) 
		{
			cerr << "error opening Gene location matrix file " << file << endl;
			exit(1);
		}


		string s;
		getline(xfile, s);
		int rowIndex = 0;
		while( !xfile.eof() ) {
		  getline(xfile, s);
		  if(s.size()<5)
			  break;
		  int lastSpace = s.find_last_of(' ');
		  string sub = s.substr(0,lastSpace);
		  int last2Space = sub.find_last_of(' ');
		  string sub1=s.substr(lastSpace+1);
		  string sub2=sub.substr(last2Space+1);
		  end = atoi(sub1.c_str());
		  start = atoi(sub2.c_str());

		  string subsub = sub.substr(0,lastSpace);
		  int last3Space = subsub.find_last_of(' ');
		  string sub3=subsub.substr(last3Space+1);
		  chr = atoi(sub3.c_str());

		  index[rowIndex][0]=start;
		  index[rowIndex][1]=chr;
		  rowIndex++;
		}

		xfile.close();
	}
	return index;

}
Matrix loaddataPathWay(const char* file,int num_genes)
{
	Matrix data(num_genes,num_genes);
	data=0;
	
	int row;
	int column;
	{
		ifstream xfile(file);

		if (!xfile.good()) 
		{
			cerr << "error opening Pathway matrix file " << file << endl;
			exit(1);
		}


		string s;
	
		data = 0;

	//	IdentityMatrix data2(4474); 
			
		while( !xfile.eof() ) {
		  xfile >> row >> column;
		  data(row+1,column+1) = 1;
		  data(column+1, row+1 ) = 1;
		}
//	    data= data+data2;
		xfile.close();
	}
	return data;

}
void printVector(const DblVec &vec, const char* filename) {
	ofstream outfile(filename);
	if (!outfile.good()) {
		cerr << "error opening matrix file " << filename << endl;
		exit(1);
	}
	outfile << "1 " << vec.size() << endl;
	for (size_t i=0; i<vec.size(); i++) {
		outfile << vec[i] << endl;
	}
	outfile.close();
}


void printMatrix2file(const Matrix &A,  const char* filename)
{

	ofstream outfile(filename);

	size_t m = A.Nrows();
	size_t n = A.Ncols();

//	outfile<<"#rows: "<<m<<", #cols: "<<n<<endl;

	for (int i=1;i<=m;i++)
	{
		for (int j=1;j<=n;j++)
		{
			outfile<<" "<<A(i,j)<<" ";
		}
		outfile<<endl;
	}
	outfile<<endl;

	outfile.close();
}

void printMatrix3(Matrix& matrix)
{
	for( int i=1; i<=matrix.Nrows();i++)
	{
		for( int j=1;j<=matrix.Ncols();j++)
		{
			cout<<matrix(i,j)<<" ";
		}
		cout<<endl;
	}


}
//void printMatrix3(Matrix& matrix)
//{
//	for( int i=1; i<=5;i++)
//	{
//		for( int j=1;j<=5;j++)
//		{
//			cout<<matrix(i,j)<<" ";
//		}
//		cout<<endl;
//	}
//
//
//}

void initialize_input(DblVec &input)
{
    srand(5);     
	float random_num;     
	float lowest=-1, highest=1;     
	float range=(highest-lowest)+1;     
	for(int index=0; index<input.size(); index++)
	{         
		random_num = lowest+(range*rand()/(RAND_MAX + 1.0));         
//		cout << random_num << endl;   
		input[index]=random_num;
	} 

}

void randomMatrix(Matrix &matrix)
{
	srand((unsigned)time(0));  
	float random_num;     
	float lowest=0, highest=1;     
	float range=(highest-lowest);    
	matrix=0;
	for(int i=1; i<=matrix.Nrows(); i++)
	{        
		for( int j =1; j<= matrix.Ncols();j++)
		{
			random_num = rand()/(RAND_MAX + 1.0);        
			matrix(i,j)=random_num;
		}
	} 

}


int matrix_non_zeros(const Matrix& A, double threshold_of_weight)
{

	int non_zeros=0;

	size_t m = A.Nrows();
	size_t n = A.Ncols();

	for (int i=1;i<=m;i++)
	{
		for (int j=1;j<=n;j++)
		{
			if (abs(A(i,j))>threshold_of_weight) 
			{
				non_zeros++;
			}

		}

	}


	return non_zeros;
}


Matrix loaddata(const char* file)
{
	Matrix data(1017,112);
	data=0;
	
	int value;

	{
		ifstream xfile(file);

		if (!xfile.good()) 
		{
			cerr << "error opening SNPs matrix file " << file << endl;
			exit(1);
		}


		string s;
		
		data = 0;
		int value;
		int rowIndex = 1;
		while( !xfile.eof() ) {
		  getline(xfile, s);

		  stringstream st(s);
		  for( int i=1; i<= 112; i++)
		  {
			  st >> value;
			  data(rowIndex,i) = value;
		  }
		  rowIndex++;
		  
		}

		xfile.close();
	}
	return data;

}

Matrix loaddata3(const char* file)
{
	Matrix data(4474,4474);
	data=0;
	
	int row;
	int column;
	{
		ifstream xfile(file);

		if (!xfile.good()) 
		{
			cerr << "error opening G0 matrix file " << file << endl;
			exit(1);
		}


		string s;
	
		data = 0;

		IdentityMatrix data2(4474); 
			
		while( !xfile.eof() ) {
		  xfile >> row >> column;
		  data(row+1,column+1) = 1;
		  data(column+1, row+1 ) = 1;
		}
	    data= data+data2;
		xfile.close();
	}
	return data;

}
Matrix loaddata1(const char* file)
{
	Matrix data(1017,1017);
	data=0;
	
	int row;
	int column;
	{
		ifstream xfile(file);

		if (!xfile.good()) 
		{
			cerr << "error opening S0 matrix file " << file << endl;
			exit(1);
		}


		string s;
	
		data = 0;

		IdentityMatrix data2(1017); 
			
		while( !xfile.eof() ) {
		  xfile >> row >> column;
		  data(row+1,column+1) = 1;
		  data(column+1, row+1 ) = 1;
		}
	    data= data+data2;
		xfile.close();
	}
	return data;

}

Matrix loaddata4(const char* file)
{
	Matrix data(4474,112);
	data=0;
	double value;

	{
		ifstream xfile(file);

		if (!xfile.good()) 
		{
			cerr << "error opening Gene matrix file " << file << endl;
			exit(1);
		}


		string s;
		data=0;

		int rowIndex = 1;
		while( !xfile.eof() ) {
		  getline(xfile, s);

		  stringstream st(s);
		  for( int i=1; i<= 112; i++)
		  {
			  st >> value;
			  data(rowIndex,i) = value;
		  }
		  rowIndex++;
		  
		}

		xfile.close();
	}
	return data;

}
Matrix gsqrt(Matrix M)
{
	Matrix result(M.Nrows(),M.Ncols());
	result=0;
	for ( int i =1; i <=M.Nrows(); i++)
	{
		for( int j=1; j<=M.Ncols(); j++)
		{
			if( M(i,j) > 0)
				result(i,j)=sqrt(M(i,j));
			else
				result(i,j) = 0;
		}
	}
	return result;

}

Matrix gdivide(Matrix M1,Matrix M2)
{
	Matrix result(M1.Nrows(),M1.Ncols());
	result=0;
	for ( int i =1; i <=M1.Nrows(); i++)
	{
		for( int j=1; j<=M1.Ncols(); j++)
		{
			if(M1(i,j)==0 && M2(i,j)==0)
			{
				result(i,j)= 0;
			}
			else if( M2(i,j)==0 )
				result(i,j) = 1000000000000;
			else
				result(i,j)=M1(i,j)/M2(i,j);
		}
	}
	return result;

}
Matrix gproduct(Matrix M1,Matrix M2)
{
	Matrix result(M1.Nrows(),M1.Ncols());
	result=0;
	for ( int i =1; i <=M1.Nrows(); i++)
	{
		for( int j=1; j<=M1.Ncols(); j++)
		{
			result(i,j)=M1(i,j)*M2(i,j);
		}
	}
	return result;

}
double Lasso_OWLQN(double eta, Matrix X, Matrix Z, Matrix & W)
{
	Lasso *prob = new Lasso(X, Z);
	int D=prob->NumInstances();
	int K=prob->NumSNPs();
	int N=prob->NumGENs();
	DifferentiableFunction *obj;
	obj = new LassoObjective(*prob);

	int dimension = K*N;

	DblVec init(dimension), ans(dimension);
	initialize_input(init);
	
	///////Setting Parameters//////////

	bool quiet = false;
	double tol = 0.5*(1e-3);//0.9*(1e-4);
	double l2weight = 0;
	int m = 10; 
	///////Iteration Starts//////////

	Matrix W_MAP(N, K);
	
	double l1weight = 0;

	l1weight=eta;
	
	OWLQN opt(quiet);
	opt.Minimize(*obj, init, ans, l1weight, tol, m);//, up_start_position);
		
	if (!quiet) cout << "Finished with optimization.  " <<endl;//<< nonZero << "/" << size << " non-zero weights." << endl;

	
	DblVec2Matrix(ans, 0, N*K-1, W_MAP);
	W=W_MAP;
	
	return 0;
}
double Lasso2(double eta, Matrix X, Matrix Z, Matrix X_X_t, Matrix Z_X_t, Matrix & W)
{
	int K=X.Nrows();
	int D=X.Ncols();
	int N=Z.Nrows();
	W=0.0;

	Matrix Wold = Matrix(N,K);
	Wold = 1;
	double TOL=0.0001;
	int MAXIT = 100;////////////////
	int iter = 0;
	
	while( (W-Wold).SumAbsoluteValue() > TOL && iter < MAXIT )
	{
		Wold = W;
		for( int i=1; i <= N; i++)
			for (int j=1; j <= K; j++ )
			{
				double temp1=0;
				double temp2=0;
				double temp3=0;
				for( int k=1;k<=K; k++)
				{
					if(k != j )
					{
						temp1=temp1+W(i,k)*X_X_t(k,j);
					}
				}
				double m=Z_X_t(i,j)-temp1;
				int sign=0;
				if(m>0)
					sign =1;
				if(m<0)
					sign=-1;
				double SS=0;
				if(abs(m)-eta>0)
					SS=sign*(abs(m)-eta);
				else
					SS=0;
				W(i,j)=SS/(X_X_t(j,j));

			}
			iter++;
			cout<<"lasso "<<iter<<endl;
	}
	Wold.Release();


	return 0;//pow((Z-W*X).NormFrobenius(),2);
}
Matrix diagSum(Matrix S)
{
	Matrix result(S.Nrows(),S.Ncols());
	result=0;
	for ( int i =1; i <=S.Nrows(); i++)
	{
		for( int j=1; j<=S.Ncols(); j++)
		{
			result(i,i)=result(i,i)+S(i,j);
		}
	}
	return result;

}
double coordinateDescent(Matrix X,Matrix Z,Matrix X_X_t,Matrix Z_X_t,double eta,double alpha,double beta, Matrix Ds,Matrix Dg,Matrix & W)
{
	int K=X.Nrows();
	int D=X.Ncols();
	int N=Z.Nrows();
	W=0;
	Matrix Wold = Matrix(N,K);
	Wold = 1;
	double TOL=0.001;
	int MAXIT = 40;//////////////////////
	int iter = 0;
	
	while( (W-Wold).SumAbsoluteValue() > TOL && iter < MAXIT )
	{
		Wold = W;
		for( int i=1; i <= N; i++)
			for (int j=1; j <= K; j++ )
			{
				double temp1=0;
				double temp2=0;
				double temp3=0;
				for( int k=1;k<=K; k++)
				{
					if(k != j )
					{
						temp1=temp1+W(i,k)*X_X_t(k,j);
						temp2=temp2+W(i,k)*Ds(k,j);
					}
				}
				for( int k=1;k<=N; k++)
				{
					if(k != i )
					{
						temp3=temp3+Dg(i,k)*W(k,j);
					}
				}
				double m=Z_X_t(i,j)-temp1-2*alpha*temp2-2*beta*temp3;
				int sign=0;
				if(m>0)
					sign =1;
				if(m<0)
					sign=-1;
				double SS=0;
				if(abs(m)-eta>0)
					SS=sign*(abs(m)-eta);
				else
					SS=0;
				double value = X_X_t(j,j)+2*alpha*Ds(j,j)+2*beta*Dg(i,i);
				if( value != 0 )
					W(i,j)=SS/value;
				else W(i,j)=0;

			}
			iter++;
			cout<<"coordinate "<<iter<<endl;
	}

	Wold.Release();

	return 0;//1/2*pow((Z-W*X).NormFrobenius(),2)+eta*W.SumAbsoluteValue()+alpha*(W*Ds*W.t()).Trace()+beta*(W.t()*Dg*W).Trace();

}
double GGDLasso_OWLQN(double eta,double lambda, double alpha,double beta,int kappa, int kappa2,Matrix X, Matrix Z, Matrix G0, Matrix S0, Matrix &W,Matrix & S, Matrix& G,Matrix Pathway, int** SNPlocation,int** Genelocation)
{
	int K=X.Nrows();
	int D=X.Ncols();
	int N=Z.Nrows();

	S=S0;
	G=G0;
	Matrix L(N,D);
	L=0;
//	Matrix X_X_t=X*X.t();
//	Matrix Z_X_t=Z*X.t();

	////////////////////////////// lasso init//////////////////////////////
//	double objLasso = Lasso_OWLQN(eta,X,Z,W);//Lasso2(eta, X, Z,X_X_t,Z_X_t, W);
	//W=loaddata6("W_eta20.txt",612,13693);
	W=loaddata6("./W_eta70.txt",612,13693);
	/////////////////////////////iteration///////////////////////////
	double TOL = 0.0001;
	int MAXITeration = 20;/////////////////////
	int iteration=0;
	Matrix oldW = Matrix(N,K);
	oldW=2.0;

	while( ( (W-oldW).SumAbsoluteValue()>TOL ) && iteration <MAXITeration )
	{
		oldW=W;
		Matrix U(Z.Nrows(),Z.Ncols());
		U=0.0;
		Matrix V(Z.Ncols(),Z.Ncols());
		V=0.0;
		DiagonalMatrix DD(Z.Ncols());
		DD=0.0;

		Matrix ttt=Z-W*X;
		

		SVD(ttt, DD, U, V);
		IdentityMatrix Diag(DD.Nrows());
		


		Matrix D_lambda=DD-lambda*Diag;
		for( int i=1; i <= D_lambda.Nrows(); i++)
				if( D_lambda(i,i) < 0)
					D_lambda(i,i)=0;
		L=U*D_lambda*V.t();

		////////////////////////////update S G//////////////////////
		
		priority_queue<Triple,vector<Triple>,compareTripleSmall> squeueS;
		priority_queue<Triple,vector<Triple>,compareTripleLarge> lqueueS;

		priority_queue<Triple,vector<Triple>,compareTripleSmall> squeueG;
		priority_queue<Triple,vector<Triple>,compareTripleLarge> lqueueG;
	//	cout<<"1: ================"<<endl;
		for(int i=1;i<W.Ncols();i++)
			for(int j=i+1;j<=W.Ncols();j++)
			{
				double value = 0;
				Matrix subM1 = W.SubMatrix(1,W.Nrows(),i,i);
				Matrix subM2 = W.SubMatrix(1,W.Nrows(),j,j);
				//for(int r=1;r<=W.Nrows();r++)
				//	value +=pow(W(r,i)-W(r,j),2);
				//value = sqrt(value);
				value=(subM1-subM2).NormFrobenius();
				if(squeueS.size()<kappa)
				{
					Triple data;
					data.row=i;
					data.column=j;
					data.weight=value;
					squeueS.push(data);
				}
				else
				{
					Triple topElement = squeueS.top();
					if(topElement.weight<value)
					{
						Triple data;
						data.row=i;
						data.column=j;
						data.weight=value;
						squeueS.pop();
						squeueS.push(data);
					}
				}

				if(lqueueS.size()<kappa)
				{
					Triple data;
					data.row=i;
					data.column=j;
					data.weight=value;
					lqueueS.push(data);
				}
				else
				{
					Triple topElement = lqueueS.top();
					if(topElement.weight>value)
					{
						Triple data;
						data.row=i;
						data.column=j;
						data.weight=value;
						lqueueS.pop();
						lqueueS.push(data);
					}
				}

				subM1.Release();
				subM2.Release();
			}

		for(int i=1;i<W.Nrows();i++)
			for(int j=i+1;j<=W.Nrows();j++)
			{
				double value = 0;
				//for(int c=1;c<=W.Ncols();c++)
				//	value +=pow(W(c,i)-W(c,j),2);
				//value = sqrt(value);
				Matrix subM1 = W.SubMatrix(i,i,1,W.Ncols());
				Matrix subM2 = W.SubMatrix(j,j,1,W.Ncols());
				value=(subM1-subM2).NormFrobenius();
				if(squeueG.size()<kappa2)
				{
					Triple data;
					data.row=i;
					data.column=j;
					data.weight=value;
					squeueG.push(data);
				}
				else
				{
					Triple topElement = squeueG.top();
					if(topElement.weight<value)
					{
						Triple data;
						data.row=i;
						data.column=j;
						data.weight=value;
						squeueG.pop();
						squeueG.push(data);
					}
				}

				if(lqueueG.size()<kappa2)
				{
					Triple data;
					data.row=i;
					data.column=j;
					data.weight=value;
					lqueueG.push(data);
				}
				else
				{
					Triple topElement = lqueueG.top();
					if(topElement.weight>value)
					{
						Triple data;
						data.row=i;
						data.column=j;
						data.weight=value;
						lqueueG.pop();
						lqueueG.push(data);
					}
				}
				subM1.Release();
				subM2.Release();
			}

		
		vector <Triple> SLeftBig;
		vector<Triple> SLeftSmall;
		vector<Triple> GLeftBig;
		vector<Triple> GLeftSmall;
		
	//cout<<"after sorting................."<<endl;
		while(!(squeueS.empty()))
		{
			Triple tri = squeueS.top();
			bool locationNB = (abs(SNPlocation[tri.row-1][0]-SNPlocation[tri.column-1][0])>=1000);
			locationNB = locationNB | (SNPlocation[tri.row-1][1]!=SNPlocation[tri.column-1][1]);
			if(S(tri.row,tri.column)==1 && locationNB)
				SLeftBig.push_back(tri);
			squeueS.pop();
		
	//		cout<<SNPlocation[tri.row-1][0]<<" "<<SNPlocation[tri.row-1][1]<<"          "<<SNPlocation[tri.column-1][0]<<" "<<SNPlocation[tri.column-1][1]<<endl;
		}
		

		while(!(lqueueS.empty()))
		{
			Triple tri = lqueueS.top();
			bool locationNB = (abs(SNPlocation[tri.row-1][0]-SNPlocation[tri.column-1][0])<=1000);
			locationNB = locationNB & (SNPlocation[tri.row-1][1]==SNPlocation[tri.column-1][1]);
			if(S(tri.row,tri.column)==0 && locationNB)
				SLeftSmall.push_back(tri);
			lqueueS.pop();
		}

		while(!(squeueG.empty()))
		{
			Triple tri = squeueG.top();
			bool samePathway = (Pathway(tri.row,tri.column)==1 || Pathway(tri.column,tri.row)==1);
			if(G(tri.row,tri.column)==1 && !samePathway)
				GLeftBig.push_back(tri);
			squeueG.pop();
		}
		while(!(lqueueG.empty()))
		{
			Triple tri = lqueueG.top();
			bool samePathway = (Pathway(tri.row,tri.column)==1 || Pathway(tri.column,tri.row)==1);
			if(G(tri.row,tri.column)==0 && samePathway)
				GLeftSmall.push_back(tri);
			lqueueG.pop();
		}

		cout<<"SNP pair: "<<SLeftSmall.size()<<"  "<<SLeftBig.size()<<" Gene pair: "<<GLeftSmall.size()<<"  "<<GLeftBig.size()<<endl;
		if((SLeftSmall.size()==0||SLeftBig.size()==0)&& (GLeftSmall.size()==0||GLeftBig.size()==0))
			break;

		int smallerS=0;
		int smallerG=0;
		if(SLeftSmall.size() < SLeftBig.size())
			smallerS=SLeftSmall.size();
		else
			smallerS=SLeftBig.size();

		if(GLeftSmall.size() < GLeftBig.size())
			smallerG=GLeftSmall.size();
		else
			smallerG=GLeftBig.size();

		for( int i = SLeftBig.size()-1;i>SLeftBig.size()-1-smallerS;i--)
		{
			Triple tri = SLeftBig.at(i);
			S(tri.row,tri.column)=0;
			S(tri.column,tri.row)=0;
		}
		for( int i = GLeftBig.size()-1;i>GLeftBig.size()-1-smallerG;i--)
		{
			Triple tri = GLeftBig.at(i);
			G(tri.row,tri.column)=0;
			G(tri.column,tri.row)=0;
		}
		for( int i = SLeftSmall.size()-1;i>SLeftSmall.size()-1-smallerS;i--)
		{
			Triple tri = SLeftSmall.at(i);
			S(tri.row,tri.column)=1;
			S(tri.column,tri.row)=1;
		}
		for( int i = GLeftSmall.size()-1;i>GLeftSmall.size()-1-smallerG;i--)
		{
			Triple tri = GLeftSmall.at(i);
			G(tri.row,tri.column)=1;
			G(tri.column,tri.row)=1;
		}

		Matrix Ds = diagSum(S)-S;
		Matrix Dg = diagSum(G)-G;

		TwoLayerLinearRegression *prob = new TwoLayerLinearRegression(X, Z-L,Ds,Dg,alpha,beta);

		DifferentiableFunction *obj;
		obj = new TwoLayerLinearRegressionObjective(*prob);

		int dimension = K*N;

		DblVec init(dimension), ans(dimension);
		initialize_input(init);
	
		///////Setting Parameters//////////

		bool quiet = false;
		double tol = 4*(1e-3);//0.9*(1e-4);
		double l2weight = 0;
		int m = 10; 
		///////Iteration Starts//////////

		Matrix W_MAP(N, K);
		W_MAP =0;
		double l1weight = 0;

		l1weight=eta;
	
		OWLQN opt(quiet);
		opt.Minimize(*obj, init, ans, l1weight, tol, m);//, up_start_position);
		
		if (!quiet) cout << "Finished with optimization.  " <<endl;//<< nonZero << "/" << size << " non-zero weights." << endl;

	
		DblVec2Matrix(ans, 0, N*K-1, W_MAP);
		W=W_MAP;
	//	W_MAP.Release();



		iteration++;
		cout<<"GC "<<iteration<<endl;
		
		U.Release();
		V.Release();
		DD.Release();
		Diag.Release();
		D_lambda.Release();
		
		Ds.Release();
		Dg.Release();

	 }

	// cout<<obj<<endl;


	 oldW.Release();


	 double obj =1.0/2.0*pow((Z-W*X-L).NormFrobenius(),2);
	 L.Release();
	
	 //X_X_t.Release();
	 //Z_X_t.Release();


	 return obj;

}
double GGDLasso(double eta,double lambda, double alpha,double beta,int kappa,int kappa2, Matrix X, Matrix Z, Matrix G0, Matrix S0, Matrix &W,Matrix & S, Matrix& G,Matrix Pathway, int** SNPlocation,int** Genelocation)
{
	int K=X.Nrows();
	int D=X.Ncols();
	int N=Z.Nrows();

	S=S0;
	G=G0;
	Matrix L(N,D);
	L=0;
	Matrix X_X_t=X*X.t();
	Matrix Z_X_t=Z*X.t();

	////////////////////////////// lasso init//////////////////////////////
	double objLasso = Lasso2(eta, X, Z,X_X_t,Z_X_t, W);
//	randomMatrix(W);
//	W=loaddata6("../code_Lasso2/W_eta20_lambda9_alpha15_beta5_gamma20_rho1.txt");

	/////////////////////////////iteration///////////////////////////
	double TOL = 0.001;
	int MAXITeration = 5;/////////////////////
	int iteration=0;
	Matrix oldW = Matrix(N,K);
	oldW=2.0;

	while( ( (W-oldW).SumAbsoluteValue()>TOL ) && iteration <MAXITeration )
	{
		oldW=W;
		Matrix U(Z.Nrows(),Z.Ncols());
		U=0.0;
		Matrix V(Z.Ncols(),Z.Ncols());
		V=0.0;
		DiagonalMatrix DD(Z.Ncols());
		DD=0.0;

		Matrix ttt=Z-W*X;
		

		SVD(ttt, DD, U, V);
		IdentityMatrix Diag(DD.Nrows());
		


		Matrix D_lambda=DD-lambda*Diag;
		for( int i=1; i <= D_lambda.Nrows(); i++)
				if( D_lambda(i,i) < 0)
					D_lambda(i,i)=0;
		L=U*D_lambda*V.t();

		////////////////////////////update S G//////////////////////
                priority_queue<Triple,vector<Triple>,compareTripleSmall> squeueS;
		priority_queue<Triple,vector<Triple>,compareTripleLarge> lqueueS;

		priority_queue<Triple,vector<Triple>,compareTripleSmall> squeueG;
		priority_queue<Triple,vector<Triple>,compareTripleLarge> lqueueG;

		for(int i=1;i<W.Ncols();i++)
			for(int j=i+1;j<=W.Ncols();j++)
			{
				double value = 0;
				Matrix subM1 = W.SubMatrix(1,W.Nrows(),i,i);
				Matrix subM2 = W.SubMatrix(1,W.Nrows(),j,j);
				//for(int r=1;r<=W.Nrows();r++)
				//	value +=pow(W(r,i)-W(r,j),2);
				//value = sqrt(value);
				value=(subM1-subM2).NormFrobenius();
				if(squeueS.size()<kappa)
				{
					Triple data;
					data.row=i;
					data.column=j;
					data.weight=value;
					squeueS.push(data);
				}
				else
				{
					Triple topElement = squeueS.top();
					if(topElement.weight<value)
					{
						Triple data;
						data.row=i;
						data.column=j;
						data.weight=value;
						squeueS.pop();
						squeueS.push(data);
					}
				}

				if(lqueueS.size()<kappa)
				{
					Triple data;
					data.row=i;
					data.column=j;
					data.weight=value;
					lqueueS.push(data);
				}
				else
				{
					Triple topElement = lqueueS.top();
					if(topElement.weight>value)
					{
						Triple data;
						data.row=i;
						data.column=j;
						data.weight=value;
						lqueueS.pop();
						lqueueS.push(data);
					}
				}

				subM1.Release();
				subM2.Release();
				//////////////////
				//cout<<lqueueS.size()<<endl;
			}

		for(int i=1;i<W.Nrows();i++)
			for(int j=i+1;j<=W.Nrows();j++)
			{
				double value = 0;
				//for(int c=1;c<=W.Ncols();c++)
				//	value +=pow(W(c,i)-W(c,j),2);
				//value = sqrt(value);
				Matrix subM1 = W.SubMatrix(i,i,1,W.Ncols());
				Matrix subM2 = W.SubMatrix(j,j,1,W.Ncols());
				value=(subM1-subM2).NormFrobenius();
				if(squeueG.size()<kappa2)
				{
					Triple data;
					data.row=i;
					data.column=j;
					data.weight=value;
					squeueG.push(data);
				}
				else
				{
					Triple topElement = squeueG.top();
					if(topElement.weight<value)
					{
						Triple data;
						data.row=i;
						data.column=j;
						data.weight=value;
						squeueG.pop();
						squeueG.push(data);
					}
				}

				if(lqueueG.size()<kappa2)
				{
					Triple data;
					data.row=i;
					data.column=j;
					data.weight=value;
					lqueueG.push(data);
				}
				else
				{
					Triple topElement = lqueueG.top();
					if(topElement.weight>value)
					{
						Triple data;
						data.row=i;
						data.column=j;
						data.weight=value;
						lqueueG.pop();
						lqueueG.push(data);
					}
				}
				subM1.Release();
				subM2.Release();
			}
		
		vector <Triple> SLeftBig;
		vector<Triple> SLeftSmall;
		vector<Triple> GLeftBig;
		vector<Triple> GLeftSmall;
		
		while(!(squeueS.empty()))
		{
			Triple tri = squeueS.top();
			bool locationNB = (abs(SNPlocation[tri.row-1][0]-SNPlocation[tri.column-1][0])>=500);
			locationNB = locationNB | (SNPlocation[tri.row-1][1]!=SNPlocation[tri.column-1][1]);
			if(S(tri.row,tri.column)==1 && locationNB)
				SLeftBig.push_back(tri);
			squeueS.pop();
		}
		

		while(!(lqueueS.empty()))
		{
			Triple tri = lqueueS.top();
			bool locationNB = (abs(SNPlocation[tri.row-1][0]-SNPlocation[tri.column-1][0])<=500);
			locationNB = locationNB & (SNPlocation[tri.row-1][1]==SNPlocation[tri.column-1][1]);
			if(S(tri.row,tri.column)==0 && locationNB)
				SLeftSmall.push_back(tri);
			lqueueS.pop();
		}

		while(!(squeueG.empty()))
		{
			Triple tri = squeueG.top();
			bool samePathway = (Pathway(tri.row,tri.column)==1 || Pathway(tri.column,tri.row)==1);
			if(G(tri.row,tri.column)==1 && !samePathway)
				GLeftBig.push_back(tri);
			squeueG.pop();
		}
		while(!(lqueueG.empty()))
		{
			Triple tri = lqueueG.top();
			bool samePathway = (Pathway(tri.row,tri.column)==1 || Pathway(tri.column,tri.row)==1);
			if(G(tri.row,tri.column)==0 && samePathway)
				GLeftSmall.push_back(tri);
			lqueueG.pop();
		}

		if((SLeftSmall.size()==0||SLeftBig.size()==0)&& (GLeftSmall.size()==0||GLeftBig.size()==0))
			break;

		int smallerS=0;
		int smallerG=0;
		if(SLeftSmall.size() < SLeftBig.size())
			smallerS=SLeftSmall.size();
		else
			smallerS=SLeftBig.size();

		if(GLeftSmall.size() < GLeftBig.size())
			smallerG=GLeftSmall.size();
		else
			smallerG=GLeftBig.size();
		cout<<"smallerS "<<smallerS<<" smallerG "<<smallerG<<endl;
		for( int i = SLeftBig.size()-1;i>SLeftBig.size()-1-smallerS;i--)
		{
			Triple tri = SLeftBig.at(i);
			S(tri.row,tri.column)=0;
			S(tri.column,tri.row)=0;
		}
		for( int i = GLeftBig.size()-1;i>GLeftBig.size()-1-smallerG;i--)
		{
			Triple tri = GLeftBig.at(i);
			G(tri.row,tri.column)=0;
			G(tri.column,tri.row)=0;
		}
		for( int i = SLeftSmall.size()-1;i>SLeftSmall.size()-1-smallerS;i--)
		{
			Triple tri = SLeftSmall.at(i);
			S(tri.row,tri.column)=1;
			S(tri.column,tri.row)=1;
		}
		for( int i = GLeftSmall.size()-1;i>GLeftSmall.size()-1-smallerG;i--)
		{
			Triple tri = GLeftSmall.at(i);
			G(tri.row,tri.column)=1;
			G(tri.column,tri.row)=1;
		}
		Matrix Ds = diagSum(S)-S;
		Matrix Dg = diagSum(G)-G;

		coordinateDescent(X,(Z-L),X_X_t,Z_X_t,eta,alpha,beta,Ds,Dg,W);
		

		iteration++;
		cout<<"GC "<<iteration<<endl;
		
		U.Release();
		V.Release();
		DD.Release();
		Diag.Release();
		D_lambda.Release();
		
		Ds.Release();
		Dg.Release();

	 }

	// cout<<obj<<endl;


	 oldW.Release();


	 double obj =1.0/2.0*pow((Z-W*X-L).NormFrobenius(),2);
	 L.Release();
	
	 X_X_t.Release();
	 Z_X_t.Release();


	 return obj;
	 
		
}
double GCLasso(double eta,double lambda, double alpha,double beta,double gamma,double rho, Matrix X, Matrix Z, Matrix G0, Matrix S0, Matrix &W,Matrix & S, Matrix& G)
{
	int K=X.Nrows();
	int D=X.Ncols();
	int N=Z.Nrows();

	S=1.0;
	G=1.0;
	Matrix L(N,D);
	L=0;
	Matrix X_X_t=X*X.t();
	Matrix Z_X_t=Z*X.t();

	////////////////////////////// lasso init//////////////////////////////
	double objLasso = Lasso2(eta, X, Z,X_X_t,Z_X_t, W);



	/////////////////////////////iteration///////////////////////////
	double TOL = 0.0001;
	int MAXITeration = 20;/////////////////////
	int iteration=0;
	Matrix oldW = Matrix(N,K);
	oldW=0;
	Matrix oldS = Matrix(S.Nrows(),S.Ncols());
	oldS=0;
	Matrix oldG = Matrix(G.Nrows(),G.Ncols());
	oldG=0;

	while( ((S-oldS).SumAbsoluteValue() > TOL || (G-oldG).SumAbsoluteValue()>TOL || (W-oldW).SumAbsoluteValue()>TOL ) && iteration <MAXITeration )
	{
		oldS=S;
		oldG=G;
		oldW=W;
		Matrix U(Z.Nrows(),Z.Ncols());
		U=0.0;
		Matrix V(Z.Ncols(),Z.Ncols());
		V=0.0;
		DiagonalMatrix DD(Z.Ncols());
		DD=0.0;

		Matrix ttt=Z-W*X;
		

		SVD(ttt, DD, U, V);
		IdentityMatrix Diag(DD.Nrows());
		


		Matrix D_lambda=DD-lambda*Diag;
		for( int i=1; i <= D_lambda.Nrows(); i++)
				if( D_lambda(i,i) < 0)
					D_lambda(i,i)=0;
		L=U*D_lambda*V.t();


		Matrix Sold(S.Nrows(), S.Ncols());
		Sold = 1.0;
		Matrix Gold(G.Nrows(), G.Ncols());
		Gold=1.0;

		TOL = 0.0001;
		int MAXIT = 100;/////////////////////
		int iter = 0;
		Matrix W_t_W = W.t()*W;
		
		Matrix W_W_t = W*W.t();
		Matrix W_t_W_pos (W_t_W);
		Matrix W_t_W_neg (W_t_W);
		for( int i=1; i <= W_t_W_pos.Nrows(); i++)
		   for ( int j=1; j<= W_t_W_pos.Ncols();j++)
				if( W_t_W_pos(i,j) < 0)
					W_t_W_pos(i,j)=0;
			for( int i=1; i <= W_t_W_neg.Nrows(); i++)
			for ( int j=1; j<= W_t_W_neg.Ncols();j++)
				if( W_t_W_neg(i,j) > 0)
					W_t_W_neg(i,j)=0;
			W_t_W_neg=-1*W_t_W_neg;
			Matrix W_W_t_pos(W_W_t);
			Matrix W_W_t_neg(W_W_t);
			for( int i=1; i <= W_W_t_pos.Nrows(); i++)
			for ( int j=1; j<= W_W_t_pos.Ncols();j++)
				if( W_W_t_pos(i,j) < 0)
					W_W_t_pos(i,j)=0;
			for( int i=1; i <= W_W_t_neg.Nrows(); i++)
			for ( int j=1; j<= W_W_t_neg.Ncols();j++)
				if( W_W_t_neg(i,j) > 0)
					W_W_t_neg(i,j)=0;
			W_W_t_neg=-1*W_W_t_neg;

			Matrix J_K(K,K);
			J_K=1.0;
			Matrix J_N(N,N);
			J_N=1.0;
			Matrix diagWtW(W_t_W.Nrows(),W_t_W.Ncols());
			diagWtW=0.0;
			for( int i =1; i <= W_t_W.Nrows(); i++)
			{
				diagWtW(i,i)=W_t_W(i,i);
			}
			Matrix diagWWt(W_W_t.Nrows(), W_W_t.Ncols());
			diagWWt=0.0;
			for( int i =1; i <= diagWWt.Nrows(); i++)
			{
				diagWWt(i,i)=W_W_t(i,i);
			}
			
			Matrix diagWtW_J_K = diagWtW*J_K;
			
			Matrix diagWWt_J_N = diagWWt*J_N;
			
		while ( ((S-Sold).SumAbsoluteValue()>TOL || (G-Gold).SumAbsoluteValue()>TOL) && iter < MAXIT )
		{
			Sold = S;
			Gold = G;
			
			Matrix temp1=alpha*W_t_W_pos+2.0*gamma*S0;

            Matrix temp2=2.0*gamma*S+alpha*W_t_W_neg+alpha*diagWtW_J_K;
            Matrix temp3=beta*W_W_t_pos+2.0*rho*G0;
            Matrix temp4=2.0*rho*G+beta*W_W_t_neg+beta*diagWWt_J_N;

            Matrix temp5 = gdivide((temp1),(temp2));
           
			Matrix temp6 = gdivide((temp3),(temp4));

			S=SP(S,gsqrt(temp5));
            G=SP(G,gsqrt(temp6));
			iter++;

			temp1.Release();
			temp2.Release();
			temp3.Release();
			temp4.Release();
			temp5.Release();
			temp6.Release();
		}

		Matrix Ds = diagSum(S)-S;
		Matrix Dg = diagSum(G)-G;

		coordinateDescent(X,(Z-L),X_X_t,Z_X_t,eta,alpha,beta,Ds,Dg,W);
		

		iteration++;
		cout<<"GC "<<iter<<endl;
		W_t_W.Release();
		W_W_t.Release();
		W_t_W_pos.Release();
		W_t_W_neg.Release();
		W_W_t_pos.Release();
		W_W_t_neg.Release();
		J_K.Release();
		J_N.Release();
		diagWtW.Release();
		diagWWt.Release();
		U.Release();
		V.Release();
		DD.Release();
		Diag.Release();
		D_lambda.Release();
		Sold.Release();
		Gold.Release();
		Ds.Release();
		Dg.Release();
		diagWtW_J_K.Release();
		diagWWt_J_N.Release();



	 }

	// cout<<obj<<endl;


	 oldW.Release();
	 oldS.Release();
	 oldG.Release();
	 
	 /*Matrix Ds = diagSum(S)-S;
	 Matrix Dg = diagSum(G)-G;
	 Matrix U(Z.Nrows(),Z.Ncols());
	 U=0;
	 Matrix V(Z.Ncols(),Z.Ncols());
	 V=0;
	 DiagonalMatrix DD(Z.Ncols());
	 DD=0;
	 SVD(L, DD, U, V);
	 double nuclear = DD.Sum();
*/
	 double obj =1.0/2.0*pow((Z-W*X-L).NormFrobenius(),2);//+eta*W.SumAbsoluteValue()+lambda*nuclear+alpha*(W*Ds*W.t()).Trace()+beta*(W.t()*Dg*W).Trace()+gamma*pow((S-S0).NormFrobenius(),2)+rho*pow((G-G0).NormFrobenius(),2);
	 L.Release();
//	 Ds.Release();
//	 Dg.Release();
//	 U.Release();
//	 V.Release();
//	 DD.Release();
	 X_X_t.Release();
	 Z_X_t.Release();

	 //printMatrix3(W);

	 return obj;
	 
		
}


Matrix pearsonCorr(Matrix A)
{
	int row = A.Nrows();
	Matrix result = Matrix(row,row);
	result=0;
	for(int i=1; i<= row; i++)
	{
		Matrix row1 = A.Row(i);
		double mean1 = 0;
		for( int j =1; j <= row1.Ncols(); j++)
			mean1+=row1(1,j);
		mean1/=row1.Ncols();

		for( int j =1; j <= row1.Ncols(); j++)
			row1(1,j)-=mean1;

		double sum_square1 = row1.NormFrobenius();

		for(int j=i; j<=row; j++)
		{
			if( i == j)
			{
				result(i,j)= 1.0;
				continue;
			}
			Matrix row2 = A.Row(j);
			double mean2 = 0;
			for( int j =1; j <= row2.Ncols(); j++)
				mean2+=row2(1,j);
			mean2/=row2.Ncols();

			for( int j =1; j <= row2.Ncols(); j++)
			row2(1,j)-=mean2;

			double sum_square2 = row2.NormFrobenius();

			double numerator= (row1*row2.t()).Sum();
			
			result(i,j) = (1+numerator/(sum_square1*sum_square2))/2;
			result(j,i) = result(i,j);


			row2.Release();
		}
		row1.Release();

	}
	return result;
	
}
Matrix getMean(Matrix M)
{
	Matrix result(1,M.Ncols());
	result=0;
	for(int i=1; i<= M.Ncols(); i++)
		for( int j=1; j<=M.Nrows();j++)
			result(1,i)+=M(j,i);
	result/=M.Nrows();
	return result;
}
double Average(vector<double> v)
{      double sum=0;
       for(int i=0;i<v.size();i++)
               sum+=v[i];
       return sum/v.size();
}

double Deviation(vector<double> v, double ave)
{
    double E=0;
    // Quick Question - Can vector::size() return 0?
    double inverse = 1.0 / static_cast<double>(v.size()-1);
    for(unsigned int i=0;i<v.size();i++)
    {
        E += pow(static_cast<double>(v[i]) - ave, 2);
    }
    return sqrt(inverse * E);
}
Matrix centralize(Matrix Z)
{
	Matrix mu_Z = getMean(Z);
	Matrix onesZ(Z.Nrows(),1);
	onesZ=1;
	
	Matrix Z_return=Z-onesZ*mu_Z;
	return Z_return;
}

Matrix normalize(Matrix& X)
{
	for( int i=1; i<= X.Nrows();i++)
	{
		std::vector<double> columnVector;
		for ( int j=1; j<= X.Ncols();j++)
		{
			columnVector.push_back(X(i,j));
		}
		double avg = Average(columnVector);
		double std = Deviation(columnVector, avg);

		for ( int j=1; j<= X.Ncols();j++)
		{
			X(i,j)-=avg;
			if( std != 0 )
				X(i,j)/=std;
		}

	}
	return X;
}
int main(int argc, char* argv[]) 
{
	/*
	const char * test1 = "[19,22,16,29,24]";
	const char * test2 = "[20,11,17,12,10]";
	const char * test3 = "[1,1,1,1,1]";
	alglib::real_1d_array x(test1);
	alglib::ae_int_t n = 5;
	alglib::real_1d_array y(test2);
	alglib::ae_int_t m = 5;
	alglib::real_1d_array z(test3);
	double both=0;
	double left=0;
	double right=0;

	
	alglib::mannwhitneyutest(  x,    n,  y,  m, both, left,  right);
	alglib::wilcoxonsignedranktest(z,5,0,both,left,right);




	*/
	const char* SNP_file = "data/snps_1_final.txt";
	const char* S_file = "data/SNPSNP_chr1.txt";
	const char* G_file ="data/mouse_PPI_chr1.txt";
	const char* Gene_file = "data/expression1_final.txt";

	double alpha=15;
	double beta=5;
	double gamma=20;
	double eta =6 ;
	double rho =1;
	double lambda=9;
	

	if(argc != 7 )
	{
		cout<<"Usage: ./main eta lambda alpha beta kappa1 kappa2"<<endl;
		return 0;
	}

	eta = atof(argv[1]);
	lambda = atof(argv[2]);
	alpha = atoi(argv[3]);
	beta = atoi(argv[4]);
	gamma = atoi(argv[5]);
	rho = atoi(argv[6]);

	Matrix X = loaddataNew(SNP_file);
	Matrix Z = loaddataNew(Gene_file);
	Matrix G0 = loaddata3New(G_file);
	Matrix S0 = loaddata1New(S_file);

	
	//Matrix X(4,4);
	//X=0.0;
	//X(1,1)=1.1;
	//X(2,2)=1.2;
	//X(1,3)=1.5;
	//X(4,1)=3.2;
	//X(1,4)=4.9;
	//X(1,2)=0.5;
	//X(2,1)=0.8;
	//X(3,1)=0.3;
	//X(3,2)=0.9;
	//X(3,3)=0.3;
	//X(3,4)=0.1;
	//X(4,2)=0.3;
	//X(4,3)=0.03;
	//X(4,4)=0.5;


	//Matrix Z(4,4);
	//Z(1,1)=0.5;
	//Z(1,2)=0.1;
	//Z(2,1)=0.3;
	//Z(2,2)=0.7;
	//Z(1,3)=0.2;
	//Z(1,4)=0.9;
	//Z(2,3)=0.1;
	//Z(2,4)=0.6;
	//Z(3,1)=0.8;
	//Z(3,2)=0.65;
	//Z(3,3)=0.37;
	//Z(3,4)=0.17;
	//Z(4,1)=0.37;
	//Z(4,2)=0.73;
	//Z(4,3)=0.71;
	//Z(4,4)=0.117;
	//Matrix G0(4,4);
	//G0=0;
	//G0(1,1)=1;
	//G0(2,2)=1;
	//Matrix S0(4,4);
	//S0=1;
	
	

	
	int K=X.Nrows();
	int D=X.Ncols();
	int N=Z.Nrows();

	Matrix W(N,K);
	W=0.0;
	Matrix S(S0.Nrows(),S0.Ncols());
	S=0.0;
	Matrix G(G0.Nrows(),G0.Ncols());
	G=0.0;
	int** SNPlocation=loadSNPlocation_mouse("data/snps_1_final_name.txt");
	int** Genelocation=loadGenelocation_mouse("data/expression1Name.txt");
	Matrix Pathway = loaddataPathWay("data/mouse_pathways_graph_1.txt");
	////////////////// normalize ///
	Z=normalize(Z);
	X=normalize(X);

	
	//Matrix Z_train = Z.SubMatrix(1,Z.Nrows(),1,Z.Ncols()/2);
	//Matrix Z_test = Z.SubMatrix(1,Z.Nrows(),Z.Ncols()/2+1,Z.Ncols());

	//Matrix X_train = X.SubMatrix(1,X.Nrows(),1,X.Ncols()/2);
	//Matrix X_test = X.SubMatrix(1,X.Nrows(),X.Ncols()/2+1,X.Ncols());


	//Z_train=centralize(Z_train);
	//Z_test=centralize(Z_test);
	//X_train=normalize(X_train);
	//X_test=normalize(X_test);
	

	//double obj = GCLasso(eta, lambda, alpha, beta, gamma, rho, X_train, Z_train, G0, S0, W, S, G);
	//double obj = GCLasso(eta, lambda, alpha, beta, gamma, rho, X, Z, G0, S0, W, S, G);

	int kappa = 100;
        kappa=gamma;
	int kappa2=rho;
	double obj = GGDLasso_OWLQN(eta, lambda, alpha, beta, kappa,kappa2, X, Z, G0, S0, W, S, G,Pathway,SNPlocation,Genelocation);
	
	//double testErr = 1.0/2.0*pow((Z_test-W*X_test).NormFrobenius(),2);


	///////Output Files//////////
	ostringstream ost_eta;
	ost_eta << eta;
	string eta_str(ost_eta.str());

	ostringstream ost_lambda;
	ost_lambda << lambda;
	string lambda_str(ost_lambda.str());

	ostringstream ost_alpha;
	ost_alpha << alpha;
	string alpha_str(ost_alpha.str());

	ostringstream ost_beta;
	ost_beta << beta;
	string beta_str(ost_beta.str());

	ostringstream ost_gamma;
	ost_gamma << gamma;
	string gamma_str(ost_gamma.str());

	ostringstream ost_rho;
	ost_rho << rho;
	string rho_str(ost_rho.str());




	string nameSuffix("_eta");
	nameSuffix.append(eta_str);
	nameSuffix.append("_lambda");
	nameSuffix.append(lambda_str);
	nameSuffix.append("_alpha");
	nameSuffix.append(alpha_str);
	nameSuffix.append("_beta");
	nameSuffix.append(beta_str);
	nameSuffix.append("_kappa");
	nameSuffix.append(gamma_str);
	nameSuffix.append("_kappa2");
	nameSuffix.append(rho_str);
	nameSuffix.append(".txt");

	
	string W_out("W");
	string S_out("S");
	string G_out("G");
	string testErr_out("obj");
	W_out.append(nameSuffix);
	S_out.append(nameSuffix);
	G_out.append(nameSuffix);
	testErr_out.append(nameSuffix);

	//printMatrix3(W);
	//printMatrix3(S);
	//printMatrix3(G);

	printMatrix2file(W,W_out.c_str());
	printMatrix2file(S,S_out.c_str());
	printMatrix2file(G,G_out.c_str());
	ofstream testErroutfile(testErr_out.c_str());
	testErroutfile<<obj<<endl;
	testErroutfile.flush();
	testErroutfile.close();

	W.Release();
	S.Release();
	G.Release();



	return 0;
}

