#include "TwoLayerLinearRegression.h"
#include <iostream>
#include <fstream>
#include <string>
#include <math.h>


using namespace std;

void printMatrix2(Matrix& matrix)
{
	for( int i=1; i<=matrix.Nrows();i++)
	{
		for( int j=1;j<=matrix.Ncols();j++)
		{
			cout<<matrix(i,j)<<" ";
		}
		cout<<endl;
	}


}


void printDblVec(const DblVec &v)
{
	for (int i=0;i<v.size();i++)
	{
		cout<<" "<<v[i]<<" ";
	}
	cout<<endl;
}

void printMatrix(const Matrix &A)
{
	size_t m = A.Nrows();
	size_t n = A.Ncols();

	cout<<"#rows: "<<m<<", #cols: "<<n<<endl;

	for (int i=1;i<=m;i++)
	{
		for (int j=1;j<=n;j++)
		{
			cout<<" "<<A(i,j)<<" ";
		}
		cout<<endl;
		getchar();
	}
	
	cout<<endl;
}



void DblVec2Matrix(const DblVec& vec, const int k1, const int k2, Matrix& A)
{
	//vec should be treated as a column vector
	//k1: start from 0, k2: ending position
	if ((k2>vec.size())||(k2-k1+1)!=(A.Nrows()*A.Ncols())) 
	{
		cerr<<"error in Vector2Matrix!";
		exit(1);
	}

	int k=k1;

	for(int j = 1; j <= A.Ncols(); j++ ) 
	{
		for (int i=1;i<=A.Nrows();i++)
		{
			A(i,j) = vec[k];
			k++;
		}
	}
}


TwoLayerLinearRegression::TwoLayerLinearRegression(Matrix X, Matrix Z_sub_L,Matrix Ds_sub_S, Matrix Dg_sub_G,double alpha,double beta)
{
	this->X = X;
	this->Z = Z_sub_L;
	this->Ds = Ds_sub_S;
	this->Dg = Dg_sub_G;
	this->alpha = alpha;
	this->beta = beta;
	N=Z.Nrows();
	K=X.Nrows();
	D=X.Ncols();
	if(D!=Z.Ncols())
		cout<<"invalid data for X and Z"<<endl;	

}

double TwoLayerLinearRegression::output_matrices()
{
	printMatrix(X);
	printMatrix(Z);

	return 0;
}



double TwoLayerLinearRegressionObjective::Eval(const DblVec& input, DblVec& gradient)
{

	    Real minsigma=1e-5;
		Real f;
	

		Real pi = 3.14159265358979323846;

		int N=problem.N;
		int K=problem.K;
		int D=problem.D;
		double alpha = problem.alpha;
		double beta = problem.beta;

		if (input.size()!=N*K) 
		{
			cerr << "error input vector size " << endl;
			exit(1);
		}

		
		Matrix W(N, K);
		

		DblVec2Matrix(input, 0, N*K-1, W);
		

		Matrix X = problem.X;
		Matrix Z = problem.Z;
		Matrix Ds = problem.Ds;
		Matrix Dg = problem.Dg;

		double tt = (Z-W*X).NormFrobenius();
		

		f = tt*tt*1/2+ (W*Ds*W.t()).Trace()*alpha+(W.t()*Dg*W).Trace()*beta;


		cout<<"  f: "<<f;

		Matrix g1(N,K);
		
		g1=0;
		
		g1=W*X*X.t()-1*Z*X.t()+2*alpha*W*Ds.t()+2*beta*Dg*W;

		int k=0;

		{for (int j=1;j<=g1.Ncols();j++)
		{
			for (int i=1;i<=g1.Nrows();i++)
			{
				gradient[k] = g1(i,j);
				k++;
			}
		}}

		W.Release();
		Dg.Release();
		Ds.Release();
		X.Release();
		Z.Release();
		g1.Release();

		return f;




}

