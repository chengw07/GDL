#pragma once

#include <fstream>
#include <string>

#include "OWLQN.h"
#include "newmatap.h"                // need matrix applications

//void printDblVec(const DblVec &v);
//
//void printMatrix(const Matrix& A);

void DblVec2Matrix2(const DblVec& vec, const int k1, const int k2, Matrix& A);

//void printMatrix2(Matrix& matrix);


class Lasso
{
	Matrix Z;
	Matrix X;
	size_t N,K,D,M;

	friend struct LassoObjective;

public:
	Lasso(size_t N, size_t K, size_t D) : X(K,D), Z(N,D), N(N), K(K), D(D){ }

	Lasso(Matrix X, Matrix Z);

	size_t NumInstances() const { return D; }	
	size_t NumSNPs() const { return K; }
	size_t NumGENs() const { return N; }

	double output_matrices();

	
};


struct LassoObjective : public DifferentiableFunction 
{
	const Lasso& problem;

	LassoObjective(const Lasso& p) : problem(p) { }

	double Eval(const DblVec& input, DblVec& gradient);

};


