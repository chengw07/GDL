#include "Lasso.h"
#include <iostream>
#include <fstream>
#include <string>
#include <math.h>


using namespace std;

//void printMatrix2(Matrix& matrix)
//{
//	for( int i=1; i<=matrix.Nrows();i++)
//	{
//		for( int j=1;j<=matrix.Ncols();j++)
//		{
//			cout<<matrix(i,j)<<" ";
//		}
//		cout<<endl;
//	}
//
//
//}
//
//
//void printDblVec(const DblVec &v)
//{
//	for (int i=0;i<v.size();i++)
//	{
//		cout<<" "<<v[i]<<" ";
//	}
//	cout<<endl;
//}
//
//void printMatrix(const Matrix &A)
//{
//	size_t m = A.Nrows();
//	size_t n = A.Ncols();
//
//	cout<<"#rows: "<<m<<", #cols: "<<n<<endl;
//
//	for (int i=1;i<=m;i++)
//	{
//		for (int j=1;j<=n;j++)
//		{
//			cout<<" "<<A(i,j)<<" ";
//		}
//		cout<<endl;
//		getchar();
//	}
//	
//	cout<<endl;
//}



void DblVec2Matrix2(const DblVec& vec, const int k1, const int k2, Matrix& A)
{
	//vec should be treated as a column vector
	//k1: start from 0, k2: ending position
	if ((k2>vec.size())||(k2-k1+1)!=(A.Nrows()*A.Ncols())) 
	{
		cerr<<"error in Vector2Matrix!";
		exit(1);
	}

	int k=k1;

	for(int j = 1; j <= A.Ncols(); j++ ) 
	{
		for (int i=1;i<=A.Nrows();i++)
		{
			A(i,j) = vec[k];
			k++;
		}
	}
}


Lasso::Lasso(Matrix X1, Matrix Z1)
{
	X=X1;
	Z=Z1;
	
	N=Z.Nrows();
	K=X.Nrows();
	D=X.Ncols();
	if(D!=Z.Ncols())
		cout<<"invalid data for X and Z"<<endl;	

}

//double Lasso::output_matrices()
//{
//	printMatrix(X);
//	printMatrix(Z);
//
//	return 0;
//}



double LassoObjective::Eval(const DblVec& input, DblVec& gradient)
{

	    Real minsigma=1e-5;
	
	

		Real pi = 3.14159265358979323846;

		int N=problem.N;
		int K=problem.K;
		int D=problem.D;

		if (input.size()!=K*N) 
		{
			cerr << "error input vector size " << endl;
			exit(1);
		}

		
		Matrix W(N, K);
		
		DblVec2Matrix2(input, 0, N*K-1,W);
		
		Matrix Z = problem.Z;
		Matrix X = problem.X;
		
		Real f = 0;

		Matrix temp = -1*Z.t()*W*X-X.t()*W.t()*Z+X.t()*W.t()*W*X;
		f = temp.Trace();



		cout<<"  f: "<<f;

		Matrix g1(N,K);
		

		g1=0;
		
		g1=-2*Z*X.t()+2*W*X*X.t();

		

	//	printMatrix(g1);	printMatrix(g2);	printMatrix(g3); cout<<g4<<endl;


		int k=0;

		{for (int j=1;j<=g1.Ncols();j++)
		{
			for (int i=1;i<=g1.Nrows();i++)
			{
				gradient[k] = g1(i,j);
				k++;
			}
		}}

		g1.Release();
		temp.Release();
		W.Release();

		return f;




}

