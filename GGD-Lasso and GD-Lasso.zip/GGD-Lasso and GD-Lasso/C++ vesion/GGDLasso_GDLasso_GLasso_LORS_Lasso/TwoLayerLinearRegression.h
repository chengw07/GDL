#pragma once

#include <fstream>
#include <string>

#include "OWLQN.h"
#include "newmatap.h"                // need matrix applications

void printDblVec(const DblVec &v);

void printMatrix(const Matrix& A);

void DblVec2Matrix(const DblVec& vec, const int k1, const int k2, Matrix& A);

void printMatrix2(Matrix& matrix);


class TwoLayerLinearRegression
{
	Matrix Z;
	Matrix X;
	Matrix Ds;
	Matrix Dg;
	size_t N,K,D;
	double alpha,beta;

	friend struct TwoLayerLinearRegressionObjective;

public:
	TwoLayerLinearRegression(size_t N, size_t K, size_t D, double a, double b) : X(K,D), Z(N,D), N(N), K(K), D(D),alpha(a),beta(b) { }

	TwoLayerLinearRegression(Matrix X, Matrix Z_sub_L,Matrix Ds_sub_S, Matrix Dg_sub_G, double alpha,double beta);

	size_t NumInstances() const { return D; }	
	size_t NumSNPs() const { return K; }
	size_t NumGENs() const { return N; }


	double output_matrices();

	
};


struct TwoLayerLinearRegressionObjective : public DifferentiableFunction 
{
	const TwoLayerLinearRegression& problem;

	TwoLayerLinearRegressionObjective(const TwoLayerLinearRegression& p) : problem(p) { }

	double Eval(const DblVec& input, DblVec& gradient);

};


