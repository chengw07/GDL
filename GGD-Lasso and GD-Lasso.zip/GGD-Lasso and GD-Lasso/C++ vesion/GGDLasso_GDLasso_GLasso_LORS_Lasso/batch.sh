bsub -q week -M 25 "./main 70 9 1 50 2000000 5000 >>recomb_GGD_70_10_1_50_2000000_5000.txt" ;
bsub -q week -M 25 "./main 70 9 50 50 2500000 5000 >>recomb_GGD_70_10_50_50_2500000_5000.txt" ;
bsub -q week -M 25 "./main 70 9 50 50 3000000 5000 >>recomb_GGD_70_10_50_50_3000000_5000.txt" ;
bsub -q week -M 25 "./main 70 9 50 50 2000000 6000 >>recomb_GGD_70_10_50_50_2000000_6000.txt" ;
bsub -q week -M 25 "./main 70 9 50 50 2000000 6000 >>recomb_GGD_70_10_50_50_2000000_7000.txt" ;
bsub -q week -M 25 "./main 70 9 50 50 2000000 8000 >>recomb_GGD_70_10_50_50_2000000_8000.txt" ;
bsub -q week -M 25 "./main 70 9 50 50 2000000 9000 >>recomb_GGD_70_10_50_50_2000000_9000.txt" ;
bsub -q week -M 25 "./main 70 9 50 50 2000000 10000 >>recomb_GGD_70_10_50_50_2000000_10000.txt" ;
