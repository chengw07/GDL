This is the C++ version of GGD-Lasso, GD-Lasso, and G-Lasso.
please use:
 gmake -f nm_gnu.mak

to compile the tools.